import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import streamlit as st
#from babel.numbers import format_currency
from matplotlib import dates
sns.set(style='dark')

#Define Dataframes
daily_df = pd.read_csv("all_data.csv")
jan11_df = daily_df.loc[(daily_df.month == 'January') & (daily_df.year == 2011)]
feb11_df = daily_df.loc[(daily_df.month == 'February') & (daily_df.year == 2011)]
march11_df = daily_df.loc[(daily_df.month == 'March') & (daily_df.year == 2011)]
april11_df = daily_df.loc[(daily_df.month == 'April') & (daily_df.year == 2011)]
may11_df = daily_df.loc[(daily_df.month == 'May') & (daily_df.year == 2011)]
june11_df = daily_df.loc[(daily_df.month == 'June') & (daily_df.year == 2011)]
july11_df = daily_df.loc[(daily_df.month == 'July') & (daily_df.year == 2011)]
aug11_df = daily_df.loc[(daily_df.month == 'August') & (daily_df.year == 2011)]
sep11_df = daily_df.loc[(daily_df.month == 'September') & (daily_df.year == 2011)]
oct11_df = daily_df.loc[(daily_df.month == 'October') & (daily_df.year == 2011)]
nov11_df = daily_df.loc[(daily_df.month == 'November') & (daily_df.year == 2012)]
dec11_df = daily_df.loc[(daily_df.month == 'December') & (daily_df.year == 2012)]
jan12_df = daily_df.loc[(daily_df.month == 'January') & (daily_df.year == 2012)]
feb12_df = daily_df.loc[(daily_df.month == 'February') & (daily_df.year == 2012)]
march12_df = daily_df.loc[(daily_df.month == 'March') & (daily_df.year == 2012)]
april12_df = daily_df.loc[(daily_df.month == 'April') & (daily_df.year == 2012)]
may12_df = daily_df.loc[(daily_df.month == 'May') & (daily_df.year == 2012)]
june12_df = daily_df.loc[(daily_df.month == 'June') & (daily_df.year == 2012)]
july12_df = daily_df.loc[(daily_df.month == 'July') & (daily_df.year == 2012)]
aug12_df = daily_df.loc[(daily_df.month == 'August') & (daily_df.year == 2012)]
sept12_df = daily_df.loc[(daily_df.month == 'September') & (daily_df.year == 2012)]
oct12_df = daily_df.loc[(daily_df.month == 'October') & (daily_df.year == 2012)]
nov12_df = daily_df.loc[(daily_df.month == 'November') & (daily_df.year == 2012)]
dec12_df = daily_df.loc[(daily_df.month == 'December') & (daily_df.year == 2012)]
monday_df = daily_df.loc[(daily_df.weekday == 'Monday')]
tuesday_df = daily_df.loc[(daily_df.weekday == 'Tuesday')]
wednesday_df = daily_df.loc[(daily_df.weekday == 'Wednesday')]
thursday_df = daily_df.loc[(daily_df.weekday == 'Thursday')]
friday_df = daily_df.loc[(daily_df.weekday == 'Friday')]
saturday_df = daily_df.loc[(daily_df.weekday == 'Saturday')]
sunday_df = daily_df.loc[(daily_df.weekday == 'Sunday')]

st.header('Capital Bikeshare Dashboard :chart:')


with st.sidebar:
    # Capital Bikeshare Logo
    st.image("capital-bikeshare-image.png")


# Callback function for Month and Year
def onClick(selection_input):
    if selection_input == 'January 2011':
        st.session_state['selection'] = 0
    if selection_input == 'February 2011':
        st.session_state['selection'] = 1
    if selection_input == 'March 2011':
        st.session_state['selection'] = 2
    if selection_input == 'April 2011':
        st.session_state['selection'] = 3
    if selection_input == 'May 2011':
        st.session_state['selection'] = 4
    if selection_input == 'June 2011':
        st.session_state['selection'] = 5
    if selection_input == 'July 2011':
        st.session_state['selection'] = 6
    if selection_input == 'August 2011':
        st.session_state['selection'] = 7
    if selection_input == 'September 2011':
        st.session_state['selection'] = 8
    if selection_input == 'October 2011':
        st.session_state['selection'] = 9
    if selection_input == 'November 2011':
        st.session_state['selection'] = 10
    if selection_input == 'December 2011':
        st.session_state['selection'] = 11
    if selection_input == 'January 2012':
        st.session_state['selection'] = 12
    if selection_input == 'February 2012':
        st.session_state['selection'] = 13
    if selection_input == 'March 2012':
        st.session_state['selection'] = 14
    if selection_input == 'April 2012':
        st.session_state['selection'] = 15
    if selection_input == 'May 2012':
        st.session_state['selection'] = 16
    if selection_input == 'June 2012':
        st.session_state['selection'] = 17
    if selection_input == 'July 2012':
        st.session_state['selection'] = 18
    if selection_input == 'August 2012':
        st.session_state['selection'] = 19
    if selection_input == 'September 2012':
        st.session_state['selection'] = 20
    if selection_input == 'October 2012':
        st.session_state['selection'] = 21
    if selection_input == 'November 2012':
        st.session_state['selection'] = 22
    if selection_input == 'December 2012':
        st.session_state['selection'] = 23

# Initialize the session state
if 'selection' not in st.session_state:
    st.session_state['selection'] = 0

# Title for Line Plot
st.sidebar.subheader("Line Chart")

# Select box
selected = st.sidebar.selectbox('Select the period (month and year):', ('January 2011', 'February 2011', 'March 2011', 'April 2011', 'May 2011', 'June 2011', 'July 2011', 'August 2011', 'September 2011', 'October 2011', 'November 2011', 'December 2011', 'January 2012', 'February 2012', 'March 2012', 'April 2012', 'May 2012', 'June 2012', 'July 2012', 'August 2012', 'September 2012', 'October 2012', 'November 2012', 'December 2012'), index=st.session_state['selection'])

# Title for Boxplot and Histogram
st.sidebar.subheader("Boxplot and Histogram")

# Select box
selected2 = st.sidebar.selectbox('Select the day :', ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), index=st.session_state['selection'])

#Callback function for Day
def onClick(selection_input):
    if selection_input == 'Monday':
        st.session_state['selection'] = 24
    if selection_input == 'Tuesday':
        st.session_state['selection'] = 25
    if selection_input == 'Wednesday':
        st.session_state['selection'] = 26
    if selection_input == 'Thursday':
        st.session_state['selection'] = 27
    if selection_input == 'Friday':
        st.session_state['selection'] = 28
    if selection_input == 'Saturday':
        st.session_state['selection'] = 29
    if selection_input == 'Sunday':
        st.session_state['selection'] = 30
    
# Initialize the session state
if 'selection' not in st.session_state:
    st.session_state['selection'] = 24

#Set condition
if selected == 'January 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = jan11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = jan11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = jan11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = jan11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=jan11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[0, 17])
    sns.lineplot(x="dteday", y="registered", data=jan11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[19, 26])

    ax.set_title("Trend on January 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)
    

if selected == 'February 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = feb11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = feb11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = feb11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = feb11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=feb11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[0, 9, 26])
    sns.lineplot(x="dteday", y="registered", data=feb11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[4, 17])
    ax.set_title("Trend on February 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'March 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = march11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = march11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = march11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = march11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=march11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[9, 18])
    sns.lineplot(x="dteday", y="registered", data=march11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[5, 17])
    
    ax.set_title("Trend on March 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'April 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = april11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = april11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = april11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = april11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=april11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[15, 29])
    sns.lineplot(x="dteday", y="registered", data=april11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[15, 25])
    
    ax.set_title("Trend on April 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'May 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = may11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = may11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = may11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = may11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=may11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[3, 28])
    sns.lineplot(x="dteday", y="registered", data=may11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[0, 11])
    
    ax.set_title("Trend on May 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'June 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = june11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = june11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = june11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = june11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=june11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[0, 25])
    sns.lineplot(x="dteday", y="registered", data=june11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[11, 29])
    
    ax.set_title("Trend on June 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'July 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = july11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = july11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = july11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = july11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=july11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[3, 21])
    sns.lineplot(x="dteday", y="registered", data=july11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[2, 14])
    
    ax.set_title("Trend on July 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'August 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = aug11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = aug11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = aug11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = aug11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=aug11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[19, 26])
    sns.lineplot(x="dteday", y="registered", data=aug11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[22, 26])
    
    ax.set_title("Trend on August 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'September 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = sep11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = sep11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = sep11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = sep11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=sep11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[3, 6])
    sns.lineplot(x="dteday", y="registered", data=sep11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[7, 29])
    
    ax.set_title("Trend on September 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'October 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = oct11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = oct11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = oct11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = oct11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=oct11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[8, 28])
    sns.lineplot(x="dteday", y="registered", data=oct11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[4, 28])
    
    ax.set_title("Trend on October 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'November 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = nov11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = nov11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = nov11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = nov11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=nov11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[11, 21])
    sns.lineplot(x="dteday", y="registered", data=nov11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[13, 23])
    
    ax.set_title("Trend on November 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'December 2011':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = dec11_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = dec11_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = dec11_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = dec11_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=dec11_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[6, 30])
    sns.lineplot(x="dteday", y="registered", data=dec11_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[1, 24])
    
    ax.set_title("Trend on December 2011", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'January 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = jan12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = jan12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = jan12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = jan12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=jan12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[6, 20])
    sns.lineplot(x="dteday", y="registered", data=jan12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[20, 30])
    
    ax.set_title("Trend on January 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'February 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = feb12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = feb12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = feb12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = feb12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=feb12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[17, 28])
    sns.lineplot(x="dteday", y="registered", data=feb12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[11, 22])
    
    ax.set_title("Trend on February 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'March 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = march12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = march12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = march12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = march12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=march12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[4, 16])
    sns.lineplot(x="dteday", y="registered", data=march12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[22, 23])
    
    ax.set_title("Trend on March 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'April 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = april12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = april12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = april12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = april12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=april12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[6, 21])
    sns.lineplot(x="dteday", y="registered", data=april12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[19, 21])
    
    ax.set_title("Trend on April 201", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'May 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = may12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = may12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = may12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = may12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=may12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[13, 18])
    sns.lineplot(x="dteday", y="registered", data=may12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[13, 15])
    
    ax.set_title("Trend on May 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'June 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = june12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = june12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = june12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = june12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=june12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[11, 15])
    sns.lineplot(x="dteday", y="registered", data=june12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[0, 6])
    
    ax.set_title("Trend on June 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'July 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = july12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = july12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = july12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = july12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=july12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[3, 19])
    sns.lineplot(x="dteday", y="registered", data=july12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[20, 24])
    
    ax.set_title("Trend on July 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'August 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = aug12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = aug12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = aug12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = aug12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=aug12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[17, 27])
    sns.lineplot(x="dteday", y="registered", data=aug12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[18, 29] )
    
    ax.set_title("Trend on August 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'September 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = sept12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = sept12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = sept12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = sept12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=sept12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[14, 17])
    sns.lineplot(x="dteday", y="registered", data=sept12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[1, 25])
    
    ax.set_title("Trend on September 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'October 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = oct12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = oct12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = oct12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = oct12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=oct12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[5, 28])
    sns.lineplot(x="dteday", y="registered", data=oct12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[9, 28])
    
    ax.set_title("Trend on October 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'November 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = nov12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = nov12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = nov12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = nov12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=nov12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[10, 26])
    sns.lineplot(x="dteday", y="registered", data=nov12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[0, 21])
    
    ax.set_title("Trend on November 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

if selected == 'December 2012':
    col1, col2, col3, col4 = st.columns(4)
 
    with col1:
        casual_min = dec12_df.casual.min()
        st.metric("Lowest rental by casual", value=casual_min)
    
    with col2:
        casual_max = dec12_df.casual.max()
        st.metric("Highest rental by casual", value=casual_max)

    with col3:
        registered_min = dec12_df.registered.min()
        st.metric("Lowest rental by registered", value=registered_min)
    
    with col4:
        registered_max = dec12_df.registered.max()
        st.metric("Highest rental by registered", value=registered_max)

    fig, ax = plt.subplots(figsize=(16, 8))

    sns.lineplot(x="dteday", y="casual", data=dec12_df, label="Casual", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[7, 25])
    sns.lineplot(x="dteday", y="registered", data=dec12_df, label="Registered", marker="o", markerfacecolor="limegreen", markersize=10, markevery=[3, 25])
    ax.set_title("Trend on December 2012", fontsize=18)
    ax.set_xlabel("Date")
    ax.set_ylabel("Number of Rentals")
    ax.xaxis.set_major_formatter(dates.DateFormatter("%d"))

    st.pyplot(fig)

#Add Title for Chart
st.subheader('Data Distribution')
#Set condition
if selected2 == 'Monday':
    col1, col2 = st.columns(2)
 
    with col1:
        fig, ax = plt.subplots()
        data_1 = monday_df.casual
        data_2 = monday_df.registered
        data = [data_1, data_2]
            
        bp = ax.boxplot(data)

        # x-axis labels
        ax.set_xticklabels(['casual', 'registered'])

        # Adding title 
        ax.set_title("Data Distribution on Monday", fontsize=18)

        st.pyplot(fig)
    
    with col2:
        fig, ax = plt.subplots()
        df = monday_df 
  
        # plotting two histograms on the same axis 
        ax.hist(df['casual'], bins=25, alpha=0.45, color='red', label='Casual') 
        ax.hist(df['registered'], bins=25, alpha=0.45, color='blue', label='Registered') 
        ax.legend()

        # Adding title 
        ax.set_title("Data Distribution on Monday", fontsize=18)

        st.pyplot(fig)

if selected2 == 'Tuesday':
    col1, col2 = st.columns(2)
 
    with col1:
        fig, ax = plt.subplots()
        data_1 = tuesday_df.casual
        data_2 = tuesday_df.registered
        data = [data_1, data_2]
            
        bp = ax.boxplot(data)

        # x-axis labels
        ax.set_xticklabels(['casual', 'registered'])

        # Adding title 
        ax.set_title("Data Distribution on Tuesday", fontsize=18)

        st.pyplot(fig)
    
    with col2:
        fig, ax = plt.subplots()
        df = tuesday_df 
  
        # plotting two histograms on the same axis 
        ax.hist(df['casual'], bins=25, alpha=0.45, color='red', label='Casual') 
        ax.hist(df['registered'], bins=25, alpha=0.45, color='blue', label='Registered') 
        ax.legend()

        # Adding title 
        ax.set_title("Data Distribution on Tuesday", fontsize=18)

        st.pyplot(fig)

if selected2 == 'Wednesday':
    col1, col2 = st.columns(2)
 
    with col1:
        fig, ax = plt.subplots()
        data_1 = wednesday_df.casual
        data_2 = wednesday_df.registered
        data = [data_1, data_2]
            
        bp = ax.boxplot(data)

        # x-axis labels
        ax.set_xticklabels(['casual', 'registered'])

        # Adding title 
        ax.set_title("Data Distribution on Wednesday", fontsize=18)

        st.pyplot(fig)
    
    with col2:
        fig, ax = plt.subplots()
        df = wednesday_df 
  
        # plotting two histograms on the same axis 
        ax.hist(df['casual'], bins=25, alpha=0.45, color='red', label='Casual') 
        ax.hist(df['registered'], bins=25, alpha=0.45, color='blue', label='Registered') 
        ax.legend()

        # Adding title 
        ax.set_title("Data Distribution on Wednesday", fontsize=18)

        st.pyplot(fig)

if selected2 == 'Thursday':
    col1, col2 = st.columns(2)
 
    with col1:
        fig, ax = plt.subplots()
        data_1 = thursday_df.casual
        data_2 = thursday_df.registered
        data = [data_1, data_2]
            
        bp = ax.boxplot(data)

        # x-axis labels
        ax.set_xticklabels(['casual', 'registered'])

        # Adding title 
        ax.set_title("Data Distribution on Thursday", fontsize=18)

        st.pyplot(fig)
    
    with col2:
        fig, ax = plt.subplots()
        df = thursday_df 
  
        # plotting two histograms on the same axis 
        ax.hist(df['casual'], bins=25, alpha=0.45, color='red', label='Casual') 
        ax.hist(df['registered'], bins=25, alpha=0.45, color='blue', label='Registered') 
        ax.legend()

        # Adding title 
        ax.set_title("Data Distribution on Thursday", fontsize=18)

        st.pyplot(fig)

if selected2 == 'Friday':
    col1, col2 = st.columns(2)
 
    with col1:
        fig, ax = plt.subplots()
        data_1 = friday_df.casual
        data_2 = friday_df.registered
        data = [data_1, data_2]
            
        bp = ax.boxplot(data)

        # x-axis labels
        ax.set_xticklabels(['casual', 'registered'])

        # Adding title 
        ax.set_title("Data Distribution on Friday", fontsize=18)

        st.pyplot(fig)
    
    with col2:
        fig, ax = plt.subplots()
        df = friday_df 
  
        # plotting two histograms on the same axis 
        ax.hist(df['casual'], bins=25, alpha=0.45, color='red', label='Casual') 
        ax.hist(df['registered'], bins=25, alpha=0.45, color='blue', label='Registered') 
        ax.legend()

        # Adding title 
        ax.set_title("Data Distribution on Friday", fontsize=18)

        st.pyplot(fig)

if selected2 == 'Saturday':
    col1, col2 = st.columns(2)
 
    with col1:
        fig, ax = plt.subplots()
        data_1 = saturday_df.casual
        data_2 = saturday_df.registered
        data = [data_1, data_2]
            
        bp = ax.boxplot(data)

        # x-axis labels
        ax.set_xticklabels(['casual', 'registered'])

        # Adding title 
        ax.set_title("Data Distribution on Saturday", fontsize=18)

        st.pyplot(fig)
    
    with col2:
        fig, ax = plt.subplots()
        df = saturday_df 
  
        # plotting two histograms on the same axis 
        ax.hist(df['casual'], bins=25, alpha=0.45, color='red', label='Casual') 
        ax.hist(df['registered'], bins=25, alpha=0.45, color='blue', label='Registered') 
        ax.legend()

        # Adding title 
        ax.set_title("Data Distribution on Saturday", fontsize=18)

        st.pyplot(fig)

if selected2 == 'Sunday':
    col1, col2 = st.columns(2)
 
    with col1:
        fig, ax = plt.subplots()
        data_1 = sunday_df.casual
        data_2 = sunday_df.registered
        data = [data_1, data_2]
            
        bp = ax.boxplot(data)

        # x-axis labels
        ax.set_xticklabels(['casual', 'registered'])

        # Adding title 
        ax.set_title("Data Distribution on Sunday", fontsize=18)

        st.pyplot(fig)
    
    with col2:
        fig, ax = plt.subplots()
        df = sunday_df 
  
        # plotting two histograms on the same axis 
        ax.hist(df['casual'], bins=25, alpha=0.45, color='red', label='Casual') 
        ax.hist(df['registered'], bins=25, alpha=0.45, color='blue', label='Registered') 
        ax.legend()

        # Adding title 
        ax.set_title("Data Distribution on Sunday", fontsize=18)

        st.pyplot(fig)






       

        

  










    
